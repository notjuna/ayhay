# Design System Specification: Cinematic Deep Space

## 1. Overview & Creative North Star: "The Cosmic Editor"
This design system is built to transcend the utility of a tool and become an immersive environment for high-end video production. The Creative North Star is **"The Cosmic Editor"**—a philosophy that treats the UI not as a flat surface, but as a vast, multi-dimensional workspace. 

We break the "template" look by rejecting rigid borders and standard grids. Instead, we use **intentional asymmetry**, where content floats within deep, atmospheric voids. High-contrast typography scales create an editorial rhythm, while overlapping "glass" surfaces and ambient glows provide the depth required for a professional, cutting-edge creative suite.

---

## 2. Colors: Tonal Atmosphere
The palette is rooted in the depth of space (`surface: #10131a`), punctuated by vibrant, gassy nebulas (`primary: #f9abff` and `secondary: #44d8f1`).

*   **The "No-Line" Rule:** We do not use 1px solid borders to define layout sections. Division is achieved strictly through background shifts. For example, a sidebar should use `surface_container_low` against the `surface` main stage.
*   **Surface Hierarchy & Nesting:** Treat the UI as layers of atmospheric density. 
    *   *Base:* `surface_container_lowest` (#0b0e14) for the most recessed areas (e.g., timeline tracks).
    *   *Mid:* `surface` (#10131a) for the primary workspace.
    *   *Top:* `surface_container_highest` (#32353c) for active panels.
*   **The "Glass & Gradient" Rule:** Floating panels must utilize Glassmorphism. Use `surface_variant` at 40% opacity with a `20px` backdrop-blur. 
*   **Signature Textures:** Main CTAs should not be flat. Use a linear gradient from `primary` (#f9abff) to `on_primary_container` (#bc48ce) at a 135-degree angle to simulate the kinetic energy of light.

---

## 3. Typography: Editorial Precision
The system pairs the technical clarity of **Inter** for UI controls with the wide, cinematic elegance of **Manrope** for display and storytelling elements.

*   **Display & Headlines (Manrope):** These are our "Hero" moments. Use `display-lg` (3.5rem) with `-0.02em` tracking for a tight, high-fashion look.
*   **Body & Labels (Inter):** To achieve a premium feel, increase letter spacing on `label-md` and `label-sm` to `0.05em`. This creates "breathing room" in dense editing interfaces.
*   **Hierarchy as Identity:** Use `tertiary` (#ffb2be) for small, all-caps metadata labels to create a sophisticated color accent that guides the eye without overwhelming the video content.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are forbidden. We define depth through light emission and tonal stacking.

*   **The Layering Principle:** Stack `surface_container_high` elements on `surface_dim` backgrounds. The "lift" comes from the value shift, mimicking how objects closer to a light source appear slightly brighter in a vacuum.
*   **Ambient Shadows:** For floating modals, use a "Cosmic Glow" instead of a shadow. Apply a blur of `32px` using a 10% opacity version of `secondary` (#44d8f1). This makes the panel appear as if it is backlit by a distant star.
*   **The "Ghost Border" Fallback:** When separation is critical (e.g., hover states on cards), use the `outline_variant` token at 15% opacity. This creates a suggestion of an edge rather than a hard boundary.
*   **Glassmorphism:** Use `surface_bright` at low opacities for playback controls, allowing the video content to "bleed" through the UI, ensuring the editor never feels disconnected from their work.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `on_primary_container`), `xl` roundedness (0.75rem), white text.
*   **Secondary:** Glass-style. `surface_variant` at 20% opacity with a `ghost border` of `primary` at 30%.
*   **Tertiary:** Ghost style. No background. `secondary` text with `label-md` styling.

### Cards & Video Thumbnails
*   **Container:** `surface_container_low` with `xl` corners. 
*   **The Content Rule:** Forbid divider lines within cards. Use `spacing.4` (1.4rem) to separate titles from descriptions. 
*   **Hover State:** Increase the `surface_container` tier by one level and apply a `secondary` ambient glow.

### Input Fields
*   **Style:** Minimalist under-lines or subtle `surface_container_highest` fills. 
*   **Focus State:** The border transitions from `outline_variant` to a soft `primary` glow. Helper text uses `label-sm`.

### Professional Video Context Components
*   **The Timeline Scrubber:** Use `secondary` (#44d8f1) for the playhead, with a `secondary_container` glow trail. 
*   **The Inspector Panel:** A vertical stack of `surface_container_low` widgets, separated only by `spacing.1.5` gaps—no borders.
*   **Selection Chips:** For filter tags, use `primary_container` with `on_primary_container` text. Roundedness must be `full` for a "pill" aesthetic.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical margins (e.g., `spacing.20` on the left, `spacing.10` on the right) for hero layouts to create a bespoke feel.
*   **Do** allow video thumbnails to take center stage; the UI should feel like a frame, not a cage.
*   **Do** use `tertiary_fixed_dim` for subtle "destructive" actions instead of bright red, to maintain the sophisticated palette.

### Don't
*   **Don't** use 100% opaque black (#000000). Always use the `surface` tokens to maintain the "Deep Space" blue-black tint.
*   **Don't** use standard "Drop Shadows." If it needs to float, it needs to glow or use tonal layering.
*   **Don't** use 1px dividers. If you need to separate content, use a background color shift or increase the vertical whitespace using `spacing.8`.